/*
* This header file is generated for C++ code to call the Fortran subroutines 
*/

extern "C" 
{
    void copse3d_();
    void helloworld_();
}



